document.addEventListener('DOMContentLoaded', function() {
    const sections = document.querySelectorAll('section');
    const navLinks = document.querySelectorAll('#navbar a');
    const cart = JSON.parse(localStorage.getItem('cart')) || [];

    function changeActiveLink(index) {
        navLinks.forEach((link) => link.classList.remove('active'));
        if (index >= 0) {
            navLinks[index].classList.add('active');
        }
    }

    function findIndexByOffset(offset) {
        let index = sections.length - 1;
        while (index >= 0 && window.scrollY + offset < sections[index].offsetTop) {
            index--;
        }
        return index;
    }

    function handleHoverIn(event) {
        const sectionId = event.target.closest('section').id;
        const link = document.querySelector(`#navbar a[href="#${sectionId}"]`);
        if (link) {
            link.classList.add('active');
        }
    }

    function handleHoverOut() {
        const currentActiveIndex = findIndexByOffset(50); // Adjust this offset as needed
        changeActiveLink(currentActiveIndex);
    }

    navLinks.forEach((link, index) => {
        link.addEventListener('mouseenter', () => changeActiveLink(index));
        link.addEventListener('mouseleave', handleHoverOut);
    });

    sections.forEach((section, index) => {
        section.addEventListener('mouseenter', () => changeActiveLink(index));
        section.addEventListener('mouseleave', handleHoverOut);
    });

    window.addEventListener('scroll', () => {
        const currentActiveIndex = findIndexByOffset(50); // Adjust this offset as needed
        changeActiveLink(currentActiveIndex);
    });

    window.addToCart = function(button) {
        const item = button.closest('.food-item');
        const imgSrc = item.querySelector('img').src;
        const priceButton = item.querySelector('.item-price');
        const price = parseFloat(priceButton.textContent.replace('Price: $', ''));
    
        cart.push({ imgSrc, price });
        localStorage.setItem('cart', JSON.stringify(cart));
        button.textContent = 'Added to Cart';
        button.disabled = true;
        button.style.backgroundColor = '#4CAF50'; // Change button color
        item.style.boxShadow = '0 4px 8px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19)'; // Apply shadow effect
        console.log('Cart:', cart);
    }

    document.getElementById('checkoutButton').addEventListener('click', function() {
        window.location.href = 'cart.html';
    });
});
